import axios from 'axios';
import React, { useEffect, useState } from 'react';

import { Link, useSearchParams } from 'react-router-dom';

const getData = (url) => {
    return axios
    .get(url, {
        headers: {
            'x-api-key': 'reqres_0e78ae308e754581bf5083b6934547ce',
        },
    })

    .then((res) => res)
    .catch((err) => err);
};

const setPageFormula= (val) => {
    console.log('---> ~ val:', val);+
}