import React from "react";

export const Page_404 = () => {
    return <div>Page_404</div>
}