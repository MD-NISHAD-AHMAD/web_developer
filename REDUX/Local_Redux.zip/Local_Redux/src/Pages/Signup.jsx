export const Signup = () =>{
    return (
        <>
            <h1>SignUp page</h1>
        </>
    )
}