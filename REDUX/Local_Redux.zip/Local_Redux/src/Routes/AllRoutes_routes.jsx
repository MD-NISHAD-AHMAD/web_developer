import { Route, Routes } from 'react-router-dom';
import React from 'react';

// import { Home } from '../Pages/Home';
import { Todo } from '../Pages/Todo';
import { Signup } from '../Pages/Signup';
import { Login } from '../Pages/Login';
// import { Counter } from '../Components/Counter';
import { Navbar } from '../Components/Navbar';
import { Home } from '../Pages/Home';
import { Counter } from '../Components/Counter';

export const AllRoutes = () => {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Signup" element={<Signup />} />
        <Route path="/todo" element={<Todo />} />
        <Route path="/Counter" element={<Counter />} />
      </Routes>
    </>
  );
};

export default AllRoutes;
