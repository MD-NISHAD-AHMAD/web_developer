import { useState } from 'react';
import './App.css';
import { Todo } from './Pages/Todo';
import { Login } from './Components/Login';
import { AllRoutes } from './Routes/AllRoutes_routes';
import { Counter } from './Components/Counter';

function App() {
  const [isLogin, setIsLogin] = useState(false);

  return (
    <>
      {isLogin ? (
        <AllRoutes />
      ) : (
        <Login setIsLogin={setIsLogin} />
      )}
    </>
  );
}

export default App;
